// import logo from "./images/logo.png";
// import heroImage from "./images/hero.jpg";
import aboutImage from "./images/aboutus.jpg";
import electronic from './images/category/cat-electrical-CsQFzspe.jpg';

import hardware from './images/category/cat-hardware-Cd0XWCa2.jpg';
import paints from './images/category/cat-paints-DudLSNxg.jpg';
import plumbing from './images/category/cat-plumbing-4Pz2eM3R.jpg';
import sanitary from './images/category/cat-sanitary-CXLiK4GH.jpg';

import imageFooter1 from './images/footer-3.svg';
import imageFooter2 from './images/footer-4.svg'; 
import categoryBg from './images/testimonial-bg.jpg'
import bgImage from './images/about-bg-1.png'
import additional from './images/additional_img01.png'
import dropBbg from './images/drop-bg.webp'

// Plumbing
import CPVC from './images/products/CPVCTee.jpg'
import PVCCoupler from './images/products/PVC-Coupler.jpg'

// paints Nerolac

import nerolacPaint1 from './images/products/nerolac/Beauty-Gold.jpg'
import nerolacPaint2 from './images/products/nerolac/Beauty-Gold-Washable.jpg'
import nerolacPaint3 from './images/products/nerolac/Beauty-Gold-Washable-plus.jpg'
import nerolacPaint4 from './images/products/nerolac/Beauty-Gold-Washable-NXT.jpg'
import nerolacPaint5 from './images/products/nerolac/Beauty-Little-Master-Sheen.jpg'
import nerolacPaint6 from './images/products/nerolac/Impressions-24-Carat.jpg'
import nerolacPaint7 from './images/products/nerolac/Impressions-Eco-Clean.jpg'
import nerolacPaint8 from './images/products/nerolac/Impressions-Kashmir.jpg'
import nerolacPaint9 from './images/products/nerolac/Impressions-Ultra-HD.jpg'
import nerolacPaint10 from './images/products/nerolac/Excel-Total.jpg'
import nerolacPaint11 from './images/products/nerolac/Mica-Marble-Stretch-Sheen.jpg'

import nerolacPaint12 from './images/products/nerolac/Excel-Anti-Peel.jpg'
import nerolacPaint13 from './images/products/nerolac/Excel-Top-Guard.jpg'

 import nerolacPaint14 from './images/products/nerolac/Premium-Primer-White.jpg'
 import nerolacPaint15 from './images/products/nerolac/Zinc-Yellow-Primer.jpg'
import nerolacPaint16 from './images/products/nerolac/Universal-PU-Primer-Grey.jpg'
import nerolacPaint17 from './images/products/nerolac/Cement-Primer.jpg'
import nerolacPaint18 from './images/products/nerolac/Water-Thinnable-Cement-Primer.jpg'
import nerolacPaint19 from './images/products/nerolac/Exterior-Primer.jpg'
import nerolacPaint20 from './images/products/nerolac/Wood-Primer-Pink.jpg'
export const assets = {
  // logo,
  // heroImage,
  aboutImage,
  electronic,
  hardware,
  paints,
  plumbing,
  sanitary,
  imageFooter1,
  imageFooter2,
  categoryBg,
  bgImage,
  additional,
  dropBbg,
  CPVC,
  PVCCoupler,
  nerolacPaint1,
  nerolacPaint2,
  nerolacPaint3,
  nerolacPaint4,
  nerolacPaint5,
  nerolacPaint6,
  nerolacPaint7,
  nerolacPaint8,
  nerolacPaint9,
  nerolacPaint10,
  nerolacPaint11,
  nerolacPaint12,
  nerolacPaint13,
  nerolacPaint14,
  nerolacPaint15,
  nerolacPaint16,
  nerolacPaint17,
  nerolacPaint18,
  nerolacPaint19,
  nerolacPaint20,
};

